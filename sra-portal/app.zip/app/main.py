# app/main.py
from sqlmodel import select
from sqlalchemy import select
from fastapi import FastAPI, Depends, HTTPException
from fastapi.security import OAuth2PasswordRequestForm
from fastapi.middleware.cors import CORSMiddleware
from app.database import get_session
from .database import create_db_and_tables
from app.auth import create_token, hash_password, verify_password
from app.models import User
from .routes.assessment import router as assessment_router  # if main.py is inside app/
from pydantic import BaseModel
from app.routes.threads import router as threads_router
app = FastAPI(title="Risk Assessments")


class RegisterRequest(BaseModel):
    email: str
    password: str
    role: str

origins = ["http://localhost:5173", "http://127.0.0.1:5173"]
    
# CORS for Vite dev server
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_methods=["*"],
    allow_headers=["*"],
    allow_credentials=True,
)

@app.on_event("startup")
def on_startup():
    create_db_and_tables()

# Include routers AFTER app is created
app.include_router(assessment_router)
app.include_router(threads_router)

@app.get("/health")
def health():
    return {"ok": True}

@app.post("/auth/login")
def login(form: OAuth2PasswordRequestForm = Depends(), session=Depends(get_session)):
    # user:User = session.exec(select(User).where(User.email == form.username)).first()
    result = session.exec(select(User).where(User.email == form.username))
    user = result.scalar_one_or_none()
    print(user)
    if not user or not verify_password(form.password, user.getPasswordHash()):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    return {"access_token": create_token(user.email, user.role), "token_type": "bearer", "role": user.role}

@app.post("/auth/register")
def register(req: RegisterRequest, session=Depends(get_session)):
    if req.role not in ("owner", "approver"):
        raise HTTPException(status_code=400, detail="Invalid role")
    if len(req.password) > 72:
        raise HTTPException(status_code=400, detail="Password must be <= 72 characters")
    existing = session.exec(select(User).where(User.email == req.email)).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email taken")
    u = User(email=req.email, password_hash=hash_password(req.password), role=req.role)
    session.add(u); session.commit(); session.refresh(u)
    return {"id": u.id, "email": u.email, "role": u.role}

