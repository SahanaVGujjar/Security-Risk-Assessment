# app/routes/assessment.py
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlmodel import Session, select
from app.models import Assessment, AssessmentStatus, User  # Import your SQLModel models
from app.database import get_session  # DB session dependency
from typing import List, Dict, Any
from jose import jwt, JWTError
from pydantic import BaseModel
from fastapi import Security


router = APIRouter(prefix="/assessments", tags=["Assessments"])

# Helper to extract user info from JWT token
SECRET = "change-me"
ALGO = "HS256"
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/login")

# 1. Create Assessment
@router.post("/", response_model=Assessment, status_code=status.HTTP_201_CREATED)
def create_assessment(assessment: Assessment, session: Session = Depends(get_session)):
    session.add(assessment)
    session.commit()
    session.refresh(assessment)
    return assessment

# 2. List Assessments
@router.get("/", response_model=List[Assessment])
def list_assessments(session: Session = Depends(get_session)):
    return session.exec(select(Assessment)).all()

# 3. Get Assessment by ID
@router.get("/{id}", response_model=Assessment)
def get_assessment(id: int, session: Session = Depends(get_session)):
    assessment = session.get(Assessment, id)
    if not assessment:
        raise HTTPException(status_code=404, detail="Assessment not found")
    return assessment

# 4. Submit PIA Screening Answers
class ScreeningAnswer(BaseModel):
    question: str
    answer: bool
    notes: str = ""

class ScreeningResponse(BaseModel):
    answers: List[ScreeningAnswer]

@router.post("/{id}/screening", status_code=status.HTTP_200_OK)
def submit_screening(
    id: int,
    body: ScreeningResponse,
    session: Session = Depends(get_session)
):
    """
    Accepts a list of answers (yes/no) for PIA screening. If any 'Yes', proceed assessment to 'in_dpia'.
    """
    assessment = session.get(Assessment, id)
    if not assessment:
        raise HTTPException(status_code=404, detail="Assessment not found")
    # Simple screening gate logic: if any answer is True (yes), start DPIA
    if any(item.answer for item in body.answers):
        assessment.status = AssessmentStatus.in_dpia
        session.commit()
        return {"message": "PIA triggered full DPIA", "next_status": assessment.status}
    else:
        assessment.status = AssessmentStatus.awaiting_approval
        session.commit()
        return {"message": "PIA screening complete, no DPIA needed", "next_status": assessment.status}

def get_current_user(token: str = Security(oauth2_scheme), session=Depends(get_session)):
    try:
        payload = jwt.decode(token, SECRET, algorithms=[ALGO])
        email = payload.get("sub"); role = payload.get("role")
        user = session.exec(select(User).where(User.email == email)).first()
        return user
    except JWTError:
        raise HTTPException(status_code=401, detail="Token invalid")