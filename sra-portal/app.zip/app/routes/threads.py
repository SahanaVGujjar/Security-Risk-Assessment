from fastapi import APIRouter, Depends, HTTPException, status
from sqlmodel import Session, select
from app.models import QuestionThread, ThreadComment
from app.database import get_session
from typing import List
from pydantic import BaseModel

router = APIRouter(prefix="/threads", tags=["Threads"])

# Start a new question thread
class ThreadCreate(BaseModel):
    assessment_id: int
    question_text: str
    opened_by: int  # Approver user id

@router.post("/", response_model=QuestionThread)
def create_thread(body: ThreadCreate, session: Session = Depends(get_session)):
    thread = QuestionThread(**body.dict())
    session.add(thread)
    session.commit()
    session.refresh(thread)
    return thread

# List threads for an assessment
@router.get("/", response_model=List[QuestionThread])
def list_threads(assessment_id: int, session: Session = Depends(get_session)):
    return session.exec(select(QuestionThread).where(QuestionThread.assessment_id == assessment_id)).all()

# Add a comment to a thread
class CommentCreate(BaseModel):
    thread_id: int
    author_id: int
    body: str

@router.post("/comment", response_model=ThreadComment)
def add_comment(body: CommentCreate, session: Session = Depends(get_session)):
    comment = ThreadComment(**body.dict())
    session.add(comment)
    session.commit()
    session.refresh(comment)
    return comment

# Get all comments for a thread
@router.get("/{thread_id}/comments", response_model=List[ThreadComment])
def get_comments(thread_id: int, session: Session = Depends(get_session)):
    return session.exec(select(ThreadComment).where(ThreadComment.thread_id == thread_id)).all()
