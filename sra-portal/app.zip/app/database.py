from sqlmodel import SQLModel, create_engine
from sqlmodel import Session


sqlite_file_name = "app.db"
sqlite_url = f"sqlite:///{sqlite_file_name}"

engine = create_engine(sqlite_url, echo=True, connect_args={"check_same_thread": False})

def create_db_and_tables():
    SQLModel.metadata.create_all(engine)

def get_session():
    engine = create_engine("sqlite:///app.db", echo=True, connect_args={"check_same_thread": False})
    with Session(engine) as session:
        yield session
